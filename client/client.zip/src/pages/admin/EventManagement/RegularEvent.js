/* eslint-disable */

import React from 'react'

export default function RegularEvent() {
  return <>wefwefe</>
}
