module.exports = {
  mongoURI: "mongodb://localhost:27017/GearMobile",
  secretOrKey: "secret",
  mailUser: 'goldendev726@gmail.com',
  mailPass: 'ddk317045',
	cardknoxKey: 'companydev9505c6799efc4f37b214763ad766366b',
	xSoftwareName: 'world nation of card',
	xSoftwareVersion: '1.0',
	transactionUrl: 'https://x1.cardknox.com/gateway',
	xVersion: '4.5.5'
};
